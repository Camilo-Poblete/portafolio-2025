
from django.shortcuts import render, redirect
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from .models import ProjectsData, SkillsData, WorkExperienceData
from utils import get_unique_categories, get_unique_technologies, validate_email
from datetime import datetime

def index(request):
    projects = ProjectsData.get_all()
    skills = SkillsData.get_all()
    technologies = get_unique_technologies(projects)
    
    return render(request, 'index_projects.html', {
        'title': 'Home',
        'projects': projects,
        'skills': skills,
        'technologies': technologies,
        'now': datetime.now(),
        'get_unique_categories': get_unique_categories,
        'get_unique_technologies': get_unique_technologies,
    })

def project_list(request):
    return redirect('/#projects')

def project_by_category(request, category):
    projects = ProjectsData.get_all()
    filtered_projects = [p for p in projects if category in p['categories']]
    technologies = get_unique_technologies(projects)
    
    return render(request, 'projects.html', {
        'title': f'Projects - {category}',
        'projects': filtered_projects,
        'active_category': category,
        'technologies': technologies,
        'now': datetime.now(),
        'get_unique_categories': get_unique_categories,
        'get_unique_technologies': get_unique_technologies,
    })

def skill_list(request):
    projects = ProjectsData.get_all()
    skills = SkillsData.get_all()
    technologies = get_unique_technologies(projects)
    
    return render(request, 'skills.html', {
        'title': 'Skills',
        'skills': skills,
        'technologies': technologies,
        'now': datetime.now(),
        'get_unique_categories': get_unique_categories,
        'get_unique_technologies': get_unique_technologies,
    })

def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        
        if not all([name, email, subject, message]):
            messages.error(request, 'Por favor, completa todos los campos.')
            return redirect('contact')
        
        if not validate_email(email):
            messages.error(request, 'Por favor, ingresa una dirección de correo electrónico válida.')
            return redirect('contact')
            
        try:
            send_mail(
                f"Contacto Portfolio: {subject}",
                f"Nombre: {name}\nEmail: {email}\n\nMensaje:\n{message}",
                settings.DEFAULT_FROM_EMAIL,
                [settings.DEFAULT_FROM_EMAIL],
                fail_silently=False,
            )
            messages.success(request, '¡Tu mensaje ha sido enviado exitosamente!')
            return redirect('/#contact')
        except Exception as e:
            messages.error(request, 'Ocurrió un error al enviar tu mensaje. Por favor, intenta nuevamente más tarde.')
            return redirect('/#contact')
    
    projects = ProjectsData.get_all()
    technologies = get_unique_technologies(projects)
    
    return render(request, 'contact.html', {
        'title': 'Contacto',
        'projects': projects,
        'technologies': technologies,
        'now': datetime.now(),
        'get_unique_categories': get_unique_categories,
        'get_unique_technologies': get_unique_technologies,
    })
