
from django.db import models

# Los modelos se mantienen como diccionarios por ahora
from models import projects, skills, work_experience

class ProjectsData:
    @staticmethod
    def get_all():
        return projects

class SkillsData:
    @staticmethod
    def get_all():
        return skills

class WorkExperienceData:
    @staticmethod
    def get_all():
        return work_experience
