
from django.contrib import admin
from django.urls import path
from core import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('projects/', views.project_list, name='project_list'),
    path('projects/<str:category>/', views.project_by_category, name='project_by_category'),
    path('skills/', views.skill_list, name='skill_list'),
    path('contact/', views.contact, name='contact'),
]
